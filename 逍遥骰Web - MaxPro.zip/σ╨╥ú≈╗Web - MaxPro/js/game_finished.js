////获取弹窗
//var win = document.getElementById('game_finished');
//
////获取调试按钮
//var call_window = document.getElementById('get_window');
//
//
//// 利用本函数呼出弹窗(为何会自动执行？)
//// 暂时使用在html设置onclick调用解决
//function Call_Window(){
//    win.style.display = "grid";
//}



/*         */

